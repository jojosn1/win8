﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestMouseMove
{
    public class MultiplyClass
    {
        public static long Multiply(long x, long y)
        {
            return (x * y);
        }
    }
}
