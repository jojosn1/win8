﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;

namespace TestMouse
{
    public partial class Form1 : Form
    {
        public delegate int HookProc(int nCode, IntPtr wParam, IntPtr lParam);

        IntPtr windowHandle;
        uint processHandle;

        //Declare hook handle as int.
        static int hHook = 0;

        //Declare mouse hook constant.
        //For other hook types, you can obtain these values from Winuser.h in Microsoft SDK.
        public const int WH_MOUSE = 7;

        //Declare MouseHookProcedure as HookProc type.
        HookProc MouseHookProcedure;

        //Declare wrapper managed POINT class.
        [StructLayout(LayoutKind.Sequential)]
        public class POINT
        {
            public int x;
            public int y;
        }

        //Declare wrapper managed MouseHookStruct class.
        [StructLayout(LayoutKind.Sequential)]
        public class MouseHookStruct
        {
            public POINT pt;
            public int hwnd;
            public int wHitTestCode;
            public int dwExtraInfo;
        }

        //Import for SetWindowsHookEx function.
        //Use this function to install thread-specific hook.
        [DllImport("user32.dll", CharSet = CharSet.Auto,
         CallingConvention = CallingConvention.StdCall)]
        public static extern int SetWindowsHookEx(int idHook, HookProc lpfn,
        IntPtr hInstance, int threadId);

        //Import for UnhookWindowsHookEx.
        //Call this function to uninstall the hook.
        [DllImport("user32.dll", CharSet = CharSet.Auto,
         CallingConvention = CallingConvention.StdCall)]
        public static extern bool UnhookWindowsHookEx(int idHook);

        //Import for CallNextHookEx.
        //Use this function to pass the hook information to next hook procedure in chain.
        [DllImport("user32.dll", CharSet = CharSet.Auto,
         CallingConvention = CallingConvention.StdCall)]
        public static extern int CallNextHookEx(int idHook, int nCode,
        IntPtr wParam, IntPtr lParam);

        [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        static extern System.IntPtr FindWindowByCaption(int ZeroOnly, string lpWindowName);

        // When you don't want the ProcessId, use this overload and pass IntPtr.Zero for the second parameter
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);


        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("DllMouseMove.dll", EntryPoint = "TestMouseMove.MultiplyClass.Multiply")]
        static extern long Multiply(long x, long y);

        private void button1_Click(object sender, EventArgs e)
        {
            MouseOperations.MousePoint mp = MouseOperations.GetCursorPosition();
            this.tbXY.Text = mp.X + ", " + mp.Y + " = " + Multiply(mp.X, mp.Y);

            //MouseOperations.SetCursorPosition(1102, 452);

            //MouseOperations.MouseEvent(
            //    MouseOperations.MouseEventFlags.LeftDown |
            //    MouseOperations.MouseEventFlags.LeftUp);
            //MouseOperations.MouseEvent(
            //    MouseOperations.MouseEventFlags.LeftDown |
            //    MouseOperations.MouseEventFlags.LeftUp);
        }

        const int WM_MOUSEMOVE = 0X0200;
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case WM_MOUSEMOVE:
                    Console.WriteLine(string.Format("{0}", DateTime.Now));
                    break;
            }
            base.WndProc(ref m);
        }

        public static int MouseHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            //Marshall the data from callback.
            MouseHookStruct MyMouseHookStruct = (MouseHookStruct)Marshal.PtrToStructure(lParam, typeof(MouseHookStruct));

            if (nCode < 0)
            {
                return CallNextHookEx(hHook, nCode, wParam, lParam);
            }
            else
            {
                //Create a string variable with shows current mouse. coordinates
                String strCaption = "x = " +
                        MyMouseHookStruct.pt.x.ToString("d") +
                            "  y = " +
                MyMouseHookStruct.pt.y.ToString("d");



                //Need to get the active form because it is a static function.
                Form tempForm = Form.ActiveForm;

                //Set the caption of the form.
                tempForm.Text = strCaption;
                return CallNextHookEx(hHook, nCode, wParam, lParam);
            }
        }

        private void btnHook_Click(object sender, EventArgs e)
        {
            if (hHook == 0)
            {
                // Create an instance of HookProc.
                MouseHookProcedure = new HookProc(Form1.MouseHookProc);
                windowHandle = FindWindowByCaption(0, "1.txt - 记事本");
                uint threadID = GetWindowThreadProcessId(windowHandle, out processHandle);
                IntPtr hMod = System.Runtime.InteropServices.Marshal.GetHINSTANCE(typeof(Form1).Module);


                hHook = SetWindowsHookEx(WH_MOUSE,
                            MouseHookProcedure,
                            hMod,
                            (int)threadID); //AppDomain.GetCurrentThreadId()
                //If SetWindowsHookEx fails.
                if (hHook == 0)
                {
                    MessageBox.Show("SetWindowsHookEx Failed");
                    return;
                }
                btnHook.Text = "UnHook Windows Hook";
            }
            else
            {
                bool ret = UnhookWindowsHookEx(hHook);
                //If UnhookWindowsHookEx fails.
                if (ret == false)
                {
                    MessageBox.Show("UnhookWindowsHookEx Failed");
                    return;
                }
                hHook = 0;
                btnHook.Text = "Set Windows Hook";
                this.Text = "Mouse Hook";
            }
        }
    }
}
