﻿namespace TestMouse
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tbXY = new System.Windows.Forms.TextBox();
            this.tbInc = new System.Windows.Forms.TextBox();
            this.btnHook = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(51, 87);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 49);
            this.button1.TabIndex = 0;
            this.button1.Text = "xy";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbXY
            // 
            this.tbXY.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbXY.Location = new System.Drawing.Point(22, 12);
            this.tbXY.Name = "tbXY";
            this.tbXY.Size = new System.Drawing.Size(95, 29);
            this.tbXY.TabIndex = 1;
            // 
            // tbInc
            // 
            this.tbInc.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbInc.Location = new System.Drawing.Point(143, 12);
            this.tbInc.Name = "tbInc";
            this.tbInc.Size = new System.Drawing.Size(95, 29);
            this.tbInc.TabIndex = 1;
            // 
            // btnHook
            // 
            this.btnHook.Location = new System.Drawing.Point(51, 157);
            this.btnHook.Name = "btnHook";
            this.btnHook.Size = new System.Drawing.Size(148, 49);
            this.btnHook.TabIndex = 0;
            this.btnHook.Text = "hook";
            this.btnHook.UseVisualStyleBackColor = true;
            this.btnHook.Click += new System.EventHandler(this.btnHook_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.tbInc);
            this.Controls.Add(this.tbXY);
            this.Controls.Add(this.btnHook);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbXY;
        private System.Windows.Forms.TextBox tbInc;
        private System.Windows.Forms.Button btnHook;
    }
}

